export type MusicCategory =
  | "MUSIC"
  | "DJ_MIXES"
  | "BEATS"
  | "CHOPPED"
  | "LOST_BOYS_RADIO";

export interface Track {
  id: string;
  title: string;
  artist: string;
  cover: string;
  duration: string;
  category: MusicCategory;
  src: string; // IMPORTANT for playback
}