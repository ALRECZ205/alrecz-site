import React from "react";
import type { MusicCategory } from "../types";

type FilterBarProps = {
  categories?: MusicCategory[];
  active: MusicCategory;
  onChange: (cat: MusicCategory) => void;
};

const LABELS: Record<MusicCategory, string> = {
  MUSIC: "Music",
  DJ_MIXES: "DJ Mixes",
  BEATS: "Beats",
  CHOPPED: "Chopped",
  LOST_BOYS_RADIO: "Lost Boyz Radio",
};

export default function FilterBar({
  categories = [],
  active,
  onChange,
}: FilterBarProps) {
  return (
    <div className="flex flex-wrap items-center gap-2 md:gap-3">
      {categories.map((cat) => {
        const isActive = active === cat;

        return (
          <button
            key={cat}
            onClick={() => onChange(cat)}
            className={[
              "relative rounded-full px-4 py-2 text-xs md:text-sm font-mono uppercase tracking-wider",
              "border transition-all duration-200",
              isActive
                ? "border-alrecz-blood text-white bg-alrecz-blood/15 shadow-[0_0_30px_rgba(122,15,15,0.25)]"
                : "border-white/15 text-gray-300 hover:text-white hover:border-white/30 hover:bg-white/5",
            ].join(" ")}
          >
            <span className="relative z-10">{LABELS[cat] ?? cat}</span>

            {isActive && (
              <span className="pointer-events-none absolute inset-0 rounded-full bg-gradient-to-r from-transparent via-alrecz-blood/10 to-transparent" />
            )}
          </button>
        );
      })}
    </div>
  );