"use client";

import React, { useMemo, useState } from "react";

import Hero from "./components/Hero";
import FilterBar from "./components/FilterBar";
import FeaturedRelease from "./components/FeaturedRelease";
import MediaRail from "./components/MediaRail";
import RadioSection from "./components/RadioSection";
import MusicPlayer from "./components/MusicPlayer";

import { TRACKS, CATEGORIES } from "./data";
import type { MusicCategory, Track } from "./types";

export default function MusicAIPage() {
  const [activeCategory, setActiveCategory] = useState<MusicCategory>("MUSIC");

  const filteredTracks = useMemo(() => {
    return TRACKS.filter((t) => t.category === activeCategory);
  }, [activeCategory]);

  // featured = first track in current category (or fallback to first overall)
  const featured: Track | undefined = filteredTracks[0] ?? TRACKS[0];

  // player state (Google AI layout usually has a persistent player)
  const [currentTrack, setCurrentTrack] = useState<Track | null>(featured ?? null);
  const [isPlaying, setIsPlaying] = useState(false);

  const onPlay = (t: Track) => {
    setCurrentTrack(t);
    setIsPlaying(true);
  };

  const onPlayPause = () => setIsPlaying((p) => !p);

  const onNext = () => {
    if (!currentTrack) return;
    const list = filteredTracks.length ? filteredTracks : TRACKS;
    const idx = list.findIndex((t) => t.id === currentTrack.id);
    const next = list[(idx + 1) % list.length];
    setCurrentTrack(next);
    setIsPlaying(true);
  };

  const onPrev = () => {
    if (!currentTrack) return;
    const list = filteredTracks.length ? filteredTracks : TRACKS;
    const idx = list.findIndex((t) => t.id === currentTrack.id);
    const prev = list[(idx - 1 + list.length) % list.length];
    setCurrentTrack(prev);
    setIsPlaying(true);
  };

  return (
    <div className="min-h-screen bg-black text-white">
      {/* HERO (top) */}
      <Hero />

      {/* Sticky filter bar + content stack */}
      <div className="relative">
        {/* subtle glow behind filter bar (Google AI vibe) */}
        <div className="pointer-events-none absolute left-1/2 top-0 h-20 w-[900px] -translate-x-1/2 bg-alrecz-blood/10 blur-3xl" />

        <div className="sticky top-0 z-40 border-b border-white/10 bg-black/80 backdrop-blur-md">
          <div className="mx-auto w-full max-w-7xl px-6 md:px-12 py-4">
            <FilterBar
              categories={CATEGORIES}
              active={activeCategory}
              onChange={(cat) => {
                setActiveCategory(cat);
                // match Google AI feel: switching category updates featured/playing softly
                const nextFeatured = TRACKS.find((t) => t.category === cat) ?? TRACKS[0];
                setCurrentTrack((cur) => (cur ? cur : nextFeatured));
              }}
            />
          </div>
        </div>

        {/* MAIN CONTENT */}
        <main className="mx-auto w-full max-w-7xl px-6 md:px-12">
          {/* Featured */}
          {featured && (
            <FeaturedRelease
              track={featured}
              onPlay={onPlay}
            />
          )}

          {/* Category rail (this is usually the “Google AI” main feel) */}
          <MediaRail
            title={activeCategory.replaceAll("_", " ")}
            tracks={filteredTracks}
            onPlay={onPlay}
          />

          {/* Radio section (below rails) */}
          <RadioSection
            tracks={TRACKS.filter((t) => t.category === "LOST_BOYS_RADIO")}
            currentTrackId={currentTrack?.id}
            onPlay={onPlay}
          />
        </main>
      </div>

      {/* Persistent Player */}
      <MusicPlayer
        currentTrack={currentTrack}
        isPlaying={isPlaying}
        onPlayPause={onPlayPause}
        onNext={onNext}
        onPrev={onPrev}
      />
    </div>
  );
}